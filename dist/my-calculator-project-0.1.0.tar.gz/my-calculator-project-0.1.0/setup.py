from setuptools import setup, find_packages

setup(
    name="my-calculator-project",  # Cambié a minúsculas y usé guiones
    version="0.1.0",
    description="Tp1- Administration Système et gestion de codes ",
    author="Luciano Alvarez Bianco",
    author_email="lucagustinalvarez1997@hotmail.com",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    url="https://github.com/Agus-Alvarez/tp1_calculator"
)

#pypi-AgENdGVzdC5weXBpLm9yZwIkZmU3MGEzODUtYmNkNS00ZTU5LTllZmEtNWI3ODRiZjhlNzg5AAIqWzMsIjQzNDdhNWZlLTkzYmItNDkwNy05ZGJmLTFkZjY0YjQ0NjA2YSJdAAAGINwHKqFNBWQQPJvyXYz8zTVu7Yrjoel4dYhtXywM2uC4
